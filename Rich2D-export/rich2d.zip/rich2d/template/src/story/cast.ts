import type {Base} from '../kit/actions';

/* Characters of this video. Key = id used in <Actor who="..."/>; `sp` = speaker code in
   lines.json (default: the id in upper case).
   THE HERO is always the same: glossy black head with white eyes and mouth (`hero: true`)
   and a red hoodie. The audience learns this silhouette in the first seconds and finds him
   in any crowd. Everyone else gets a real face and a look that fits the story.
   Look fields (all optional):
     color     hoodie / jacket / dress colour
     outfit    hoodie | tee | suit | coat | apron | dress
     build     m (broad shoulders) | f (waist, hips) | k (kid, smaller frame)
     hair      none | short | spiky | long | bob | bun | ponytail | cap | grey ; hairColor
     skin      skin tone, e.g. #f3cba8 light, #e2b48a, #c98d63, #8d5a3b dark
     eye       iris colour; lash (lashes, on by default for build f); beard; glasses via acc
     acc       [headphones | mustache | glasses]; bag = backpack colour
     legColor  trousers; shoe = sneakers; age 0..1 = wrinkles and eye bags
   Pick every look from the story: a teacher is older and wears a suit, a kid is build k,
   a doctor wears a white coat, a seller an apron. See references/world.md. */
export type CastMember = Base & {sp?: string};

export const CAST: Record<string, CastMember> = {
	hero: {color: '#ff2540', hero: true, outfit: 'hoodie', legColor: '#1c1a26', shoe: '#f4f1ea', rim: '#ffd0d6', rimW: 2.4},
	friend: {color: '#3d6fe0', hair: 'spiky', hairColor: '#8a3f1e', skin: '#e6b088', eye: '#6b4a2a', legColor: '#2b2f3a', rim: '#ffe0c8', rimW: 2.4, shoe: '#f2f2f2'},
	mom: {color: '#7a5cc4', outfit: 'tee', build: 'f', hair: 'bob', hairColor: '#4a2c22', skin: '#e9b58c', eye: '#8a5a2a', legColor: '#3a3f5c', rim: '#ffe6c8', rimW: 2.4, shoe: '#2c2540'},
	girl: {color: '#8b5cf6', outfit: 'hoodie', build: 'f', hair: 'ponytail', hairColor: '#ffb02e', skin: '#f6d2b4', eye: '#3aa0e0', acc: ['headphones'], legColor: '#2d3a63', rim: '#efe2ff', rimW: 2.4, shoe: '#efe2ff'},
	teacher: {color: '#8e3a4f', outfit: 'suit', build: 'f', hair: 'bun', hairColor: '#4a2c22', acc: ['glasses'], skin: '#f1c4a0', eye: '#6a4a3a', age: 0.35, legColor: '#2b1d24', rim: '#ffe6d6', rimW: 2.4, shoe: '#2b1d24'},
	guard: {color: '#3a4256', outfit: 'suit', hair: 'cap', hairColor: '#28304a', acc: ['mustache'], skin: '#c98d63', eye: '#4a3a2a', legColor: '#22262e', rim: '#e6ecff', rimW: 2.4, shoe: '#111'},
	doctor: {color: '#eef3f2', outfit: 'coat', build: 'f', hair: 'long', hairColor: '#2b1f3a', skin: '#8d5a3b', eye: '#3a2a1a', legColor: '#2c3a40', rim: '#d8fff2', rimW: 2.4, shoe: '#2c3a40'},
	seller: {color: '#3aa37a', outfit: 'apron', build: 'f', hair: 'bun', hairColor: '#d9d9d9', skin: '#e8b48c', eye: '#5a7a6a', age: 0.5, legColor: '#1d2b24', rim: '#e8fff2', rimW: 2.4, shoe: '#1d2b24'},
	grandpa: {color: '#6b7f8e', outfit: 'tee', hair: 'grey', hairColor: '#d9d9d9', beard: true, acc: ['glasses'], skin: '#e8b48c', eye: '#6a7a8a', age: 0.7, legColor: '#3a3f4b', rim: '#eef4ff', rimW: 2.4, shoe: '#2b2f3a'},
};
