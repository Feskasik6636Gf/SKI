# Своя озвучка: пользователь прислал готовый аудиофайл

Так делаем, когда есть mp3/wav и нет текста. Это путь, которым собран ролик про круглые окна самолёта.

## 1. Распознать текст и тайминги
Модель не обязана быть в проекте: ставим один раз `pip install faster-whisper` (модель `small` скачается сама). Если `av` ругается на `metadata_errors`, не отдавай файл напрямую: сначала декодируй ffmpeg в сырой float32.
```bash
ffmpeg -y -i voice.mp3 -ac 1 -ar 16000 -f f32le voice.f32          # ffmpeg лежит в node_modules/@remotion/compositor-*
```
```python
import json, numpy as np
from faster_whisper import WhisperModel
m = WhisperModel("small", device="cpu", compute_type="int8")
segs, _ = m.transcribe(np.fromfile("voice.f32", dtype="float32"), language="ru", beam_size=5)
out = [{"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()} for s in segs]
json.dump(out, open("stt.json", "w"), ensure_ascii=False, indent=1)
```
Прочитай текст сам и поправь ошибки распознавания (падежи, редкие слова: «иллюминатор», имена). Тексту верь не слепо: показывай пользователю одной строкой, что услышал.

## 2. Нарезать на реплики
Одна фраза = одна реплика `NNN_N.mp3` (`N` — рассказчик) в `public/vo/`. Режь посередине паузы между фразами:
`ffmpeg -ss <середина паузы до> -to <середина паузы после> -ac 1 -b:a 128k public/vo/001_N.mp3`.
В `src/story/lines.json` у каждой реплики поля `id`, `sp`, `t` (исправленный текст) и **`gap`** = реальная пауза до следующей фразы минус 0,05 с (минимум 0,08), чтобы ритм остался авторским. Потом `node tools/prep-timeline.mjs`: ни одной строки `CHECK`.

## 3. Дальше как обычно
Шаги 4–9 `SKILL.md`: таблица сцен по `world.md`, сцены, `check-style`, `check-plans`, звук, рендер, превью. Голос не синтезируй (`voice-free` не нужен). Если ролик длиннее 60 с, это уже лонг 16:9, шортс из него режь отдельно.
